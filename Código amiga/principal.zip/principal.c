#include <stdio.h> // para printf
#include <conio.h> // para getche
#include <string.h> // para usar strcpy
#include <time.h> // para trazer hora atual
#include <locale.h> // para arrumar acentua��o
#include <stdlib.h> //para limpar a tela

	struct _onibus
	{
		char poltronas[36];
		int totidosos;
		int totestudantes;
		int totnormal;
		int totdisponiveis;
	};

	//declara��o das vari�veis globais:
	const float vpassagem = 115; // valor da passagem
		

	char onibusescolhido = '0';
	struct _onibus onibus1={0};
	struct _onibus onibus2={0};
	struct _onibus onibus3={0};
	struct _onibus onibusatual={0};

char MenuHorario(){
	
	char opcao2='0'; // op��es do menu de hor�rios
	char retorno;
	
	int idosos1=0;
	int idosos2=0;
	int idosos3=0;
	
	if (2-onibus1.totidosos > onibus1.totdisponiveis) {
		idosos1=onibus1.totdisponiveis;
	}
	else {
		idosos1=2-onibus1.totidosos;
	}

	if (2-onibus2.totidosos > onibus2.totdisponiveis) {
		idosos2=onibus2.totdisponiveis;
	}
	else {
		idosos2=2-onibus2.totidosos;
	}	

	if (2-onibus3.totidosos > onibus3.totdisponiveis) {
		idosos3=onibus3.totdisponiveis;
	}
	else {
		idosos3=2-onibus3.totidosos;
	}
	
	while (opcao2!='1' && opcao2!='2' && opcao2!='3') {
		system ( "cls" ); 
		printf("Escolha o hor�rio desejado:\n\n 1-9:00 (%d lugares dispon�veis, %d para idosos)\n 2-12:00 (%d lugares dispon�veis, %d para idosos)\n 3-15:00 (%d lugares dispon�veis, %d para idosos)\n\n",onibus1.totdisponiveis,idosos1,onibus2.totdisponiveis,idosos2,onibus3.totdisponiveis,idosos3);
		opcao2=getche();
		
		if (opcao2!='1' && opcao2!='2' && opcao2!='3') {
			printf("\nOp��o inv�lida. Escolha uma op��o da lista.\n\n");
			system("pause");
		}
		else if ((opcao2=='1' && onibus1.totdisponiveis==0) || (opcao2=='2' && onibus2.totdisponiveis==0) || (opcao2=='3' && onibus3.totdisponiveis==0)) {
			printf("\nEsse �nibus n�o possui lugares dispon�veis.\n\n");
			system("pause");
			retorno = '0';
		}
		else {
			retorno = opcao2;
		}
	}
	return retorno;
}

char MenuTipo(){

		
	char opcao3='0'; // op��es do menu tipo
	
	while (opcao3!='1' && opcao3!='2' && opcao3!='3'){
		
		inicioTipo:
			system ( "cls" ); 
			if (onibusescolhido=='1') {
				printf("Escolha o tipo da passagem:\n\n 1-Idoso (%d lugares vendidos)\n 2-Estudante\n 3-Normal\n\n",onibus1.totidosos);
				opcao3=getche();
				//scanf("%d",&opcao3);
				//setbuf(stdin,NULL);
	
				if (opcao3=='1' && 2-onibus1.totidosos==0){
					printf("\nAs passagens para idosos j� se esgotaram. Favor escolher outro tipo.\n\n");
					system("pause");
					goto inicioTipo;
				}
				if(opcao3!='1' && opcao3!='2' && opcao3!='3'){
					printf("\nOp��o inv�lida. Escolha uma op��o da lista.\n\n");
					system("pause");
				}
			}
			else if (onibusescolhido=='2') {
				printf("Escolha o tipo da passagem:\n\n 1-Idoso (%d lugares vendidos)\n 2-Estudante\n 3-Normal\n\n",onibus2.totidosos);
				opcao3=getche();
				
				if (opcao3=='1' && 2-onibus2.totidosos==0){
					printf("\nAs passagens para idosos j� se esgotaram. Favor escolher outro tipo.\n\n");
					system("pause");
					goto inicioTipo;
				}
				if(opcao3!='1' && opcao3!='2' && opcao3!='3'){
					printf("\nOp��o inv�lida. Escolha uma op��o da lista.\n\n");
					system("pause");
				}
			}
			else if (onibusescolhido=='3') {
				printf("Escolha o tipo da passagem:\n\n 1-Idoso (%d lugares vendidos)\n 2-Estudante\n 3-Normal\n\n",onibus3.totidosos);
				opcao3=getche();
				
				if (opcao3=='1' && 2-onibus3.totidosos==0){
					printf("\nAs passagens para idosos j� se esgotaram. Favor escolher outro tipo.\n\n");
					system("pause");
					goto inicioTipo;
				}
				if(opcao3!='1' && opcao3!='2' && opcao3!='3'){
					printf("\nOp��o inv�lida. Escolha uma op��o da lista.\n\n");
					system("pause");
				}
			}
	}
	return opcao3;
}

int MenuQuantidade(char tipo){
	inicioQtd:
		system ( "cls" ); 
		int qtd; // valor de quantidade informado
		int maxpassagem; // m�ximo de passagens permitidas nessa compra
		
		printf( "\nEntre com a quantidade desejada: " );
		scanf("%d",&qtd);
		setbuf(stdin,NULL);
	
		if (!(qtd>=1 && qtd<=36)){
			printf("\nFavor entrar com um n�mero v�lido.\n\n");
			system("pause");
			goto inicioQtd;
		}

		if (onibusescolhido=='1') {
			if (tipo=='1'){
				if (2-onibus1.totidosos > onibus1.totdisponiveis) {
					maxpassagem=onibus1.totdisponiveis;
				}
				else {
					maxpassagem=2-onibus1.totidosos;
				}				
			}
			else{
				maxpassagem=onibus1.totdisponiveis;
			}
		}
		else if(onibusescolhido=='2'){
			if (tipo=='1'){
				if (2-onibus2.totidosos > onibus2.totdisponiveis) {
					maxpassagem=onibus2.totdisponiveis;
				}
				else {
					maxpassagem=2-onibus2.totidosos;
				}
			}
			else{
				maxpassagem=onibus2.totdisponiveis;
			}
		}
		else if(onibusescolhido=='3'){
			if (tipo=='1'){
				if (2-onibus3.totidosos > onibus3.totdisponiveis) {
					maxpassagem=onibus3.totdisponiveis;
				}
				else {
					maxpassagem=2-onibus3.totidosos;
				}				
			}
			else{
				maxpassagem=onibus3.totdisponiveis;
			}
		}
	
		if (qtd > maxpassagem){
			printf("\nN�o � poss�vel comprar essa quantidade. Favor rever.\n\n");
			system("pause");
			goto inicioQtd;
		}
			
		return qtd;
}

void ImprimeDisponiveis(){
	int i; // contador
	
	system ( "cls" ); 
	printf("Verifique os assentos dispon�veis na pr�xima p�gina\n\n");
	system("pause");
	
	if (onibusescolhido=='1') {
		for (i=0;i<36;i++) {
			if (onibus1.poltronas[i]==0 && onibusatual.poltronas[i]==0) {
				printf("Assento %d\n",i+1);
			}
		}
	}
	else if (onibusescolhido=='2') {
		for (i=0;i<36;i++) {
			if (onibus2.poltronas[i]==0 && onibusatual.poltronas[i]==0) {
				printf("Assento %d\n",i+1);
			}
		}
	}
	else if (onibusescolhido=='3') {
		for (i=0;i<36;i++) {
			if (onibus3.poltronas[i]==0 && onibusatual.poltronas[i]==0) {
				printf("Assento %d\n",i+1);
			}
		}
	}
	system("pause");
}

int ChecaRepetido(int assento){
	int repetido=0;
	
	if (onibusescolhido=='1') {
		if (onibus1.poltronas[assento-1]!=0 || onibusatual.poltronas[assento-1]!=0){
			repetido=1;
		}
	}
	else if (onibusescolhido=='2') {
		if (onibus2.poltronas[assento-1]!=0 || onibusatual.poltronas[assento-1]!=0){
			repetido=1;
		}
	}
	else if (onibusescolhido=='3') {
		if (onibus3.poltronas[assento-1]!=0 || onibusatual.poltronas[assento-1]!=0){
			repetido=1;
		}
	}
	return repetido;
}

void MenuAssento(int qtd,char tipo){
	
	int assento=0; // assento escolhido
	int i;
	int repetido;
	
	   	
	for (i=0;i<qtd;i++) {
		while (assento < 1 || assento > 36) {
		
			assentocon:
				system ( "cls" ); 
				
				printf("Entre com o %d� assento escolhido:",i+1);
				scanf("%d",&assento);
				setbuf(stdin,NULL);
				
				if (assento < 1 || assento > 36){
					printf("\nAssento inv�lido. Favor digitar um n�mero de 1 a 36.\n\n");
					system("pause");
				} 
				else{
						
					system ( "cls" ); 
						
					repetido = ChecaRepetido(assento);  // Checar se o assento escolhido j� est� ocupado
					if (repetido==1){
						//system ( "cls" ); 
						printf("\nEsse assento j� est� ocupado. Favor escolher outro.\n\n");
						system("pause");
						goto assentocon;
					}
						
					onibusatual.poltronas[assento-1] = tipo;
			}
		}
		assento = 0;
	}

}

void ZeraCompra(){
	int i; //contador
	
	for (i=0;i<36;i++) {
	   onibusatual.poltronas[i] = 0;
	}	
}

void ConfirmaCompra(int qtd,char tipopassagem,int dia,int mes,int ano){

	setbuf(stdin,NULL);
	int i; // contador
	char opcao4='0'; //opcao do menu escolhida
	char txtipo[10]; // texto do tipo da passagem
	

	while (opcao4 != '1' && opcao4 != '2'){
		system ( "cls" ); 
		printf("Assentos selecionados:\n");
		for (i=0;i<36;i++) {
			if (onibusatual.poltronas[i] != 0){
				printf("Assento %d\n",i+1);
			}
		}
			
		printf("\n\nConfirma compra?\n 1-Confirmar\n 2-Cancelar\n\n");
		opcao4=getche();
					
		if(opcao4!='1' && opcao4!='2'){
			printf("\nOp��o inv�lida. Escolha um item da lista.\n\n");
			system("pause");
		}
		else if(opcao4=='1') {
			
			printf("\n\nNas pr�ximas telas ser�o impressos os tickets dessa compra.\n\n");
			system("pause");
						
			if (onibusescolhido=='1'){
				if (tipopassagem == '1') {
					onibus1.totidosos = onibus1.totidosos + qtd;
					strcpy(txtipo,"Idoso");
				}
				else if (tipopassagem == '2'){
					onibus1.totestudantes = onibus1.totestudantes + qtd;
					strcpy(txtipo,"Estudante");
				}
				else if (tipopassagem == '3'){
					onibus1.totnormal = onibus1.totnormal + qtd;
					strcpy(txtipo,"Normal");
				}
				
				onibus1.totdisponiveis = onibus1.totdisponiveis - qtd;
				
				for (i=0;i<36;i++) {
					if (onibusatual.poltronas[i] != 0) {
						onibus1.poltronas[i] = tipopassagem;
						
						system ( "cls" ); 
						printf("\n\nN�mero da poltrona: %d\n",i+1);
						printf("Tipo da passagem: %s\n",txtipo);
						printf("Data: %d/%d/%d\n",dia,mes,ano);
						printf("Hor�rio: 09:00\nOrigem: S�o Paulo\nDestino: Rio de Janeiro\n�nibus n�mero: %c\n\n",onibusescolhido);
						system("pause");
					}
				}
			}
			else if (onibusescolhido=='2'){
				if (tipopassagem == '1') {
					onibus2.totidosos = onibus2.totidosos + qtd;
					strcpy(txtipo,"Idoso");
				}
				else if (tipopassagem == '2'){
					onibus2.totestudantes = onibus2.totestudantes + qtd;
					strcpy(txtipo,"Estudante");
				}
				else if (tipopassagem == '3'){
					onibus2.totnormal = onibus2.totnormal + qtd;
					strcpy(txtipo,"Normal");
				}
				
				onibus2.totdisponiveis = onibus2.totdisponiveis - qtd;
			
				for (i=0;i<36;i++) {
					if (onibusatual.poltronas[i] != 0) {
						onibus2.poltronas[i] = tipopassagem;
						
						system ( "cls" ); 
						printf("\n\nN�mero da poltrona: %d\n",i+1);
						printf("Tipo da passagem: %s\n",txtipo);
						printf("Data: %d/%d/%d\n",dia,mes,ano);
						printf("Hor�rio: 09:00\nOrigem: S�o Paulo\nDestino: Rio de Janeiro\n�nibus n�mero: %c\n\n",onibusescolhido);
						system("pause");
					}
				}
			}
			else if (onibusescolhido=='3'){
				if (tipopassagem == '1') {
					onibus3.totidosos = onibus3.totidosos + qtd;
					strcpy(txtipo,"Idoso");
				}
				else if (tipopassagem == '2'){
					onibus3.totestudantes = onibus3.totestudantes + qtd;
					strcpy(txtipo,"Estudante");
				}
				else if (tipopassagem == '3'){
					onibus3.totnormal = onibus3.totnormal + qtd;
					strcpy(txtipo,"Normal");
				}
				
				onibus3.totdisponiveis = onibus3.totdisponiveis - qtd;
		
				for (i=0;i<36;i++) {
					if (onibusatual.poltronas[i] != 0) {
						onibus3.poltronas[i] = tipopassagem;

						system ( "cls" ); 
						printf("\n\nN�mero da poltrona: %d\n",i+1);
						printf("Tipo da passagem: %s\n",txtipo);
						printf("Data: %d/%d/%d\n",dia,mes,ano);
						printf("Hor�rio: 09:00\nOrigem: S�o Paulo\nDestino: Rio de Janeiro\n�nibus n�mero: %c\n\n",onibusescolhido);
						system("pause");
					}
				}
			}
			
			ZeraCompra();
		}
		else if(opcao4=='2') {
			ZeraCompra();
		}
	}
	//return opcao4;
}

void FechaCaixa(){

		float totonibus1=0;
		float totonibus2=0;
		float totonibus3=0;
		float totalgeral=0;
		
		totonibus1=onibus1.totestudantes * (vpassagem/2);
		totonibus1=totonibus1 + onibus1.totnormal * vpassagem;

		totonibus2=onibus2.totestudantes * (vpassagem/2);
		totonibus2=totonibus2 + onibus2.totnormal * vpassagem;

		totonibus3=onibus3.totestudantes * (vpassagem/2);
		totonibus3=totonibus3 + onibus3.totnormal * vpassagem;
		
		totalgeral = totonibus1 + totonibus2 + totonibus3;
		
		system ( "cls" ); 
		printf("\n�nibus 1 - 09:00\nIdosos: %d\nEstudantes: %d\nNormais: %d\nTotal: R$ %8.2f\n",onibus1.totidosos,onibus1.totestudantes,onibus1.totnormal,totonibus1);
		printf("\n�nibus 2 - 12:00\nIdosos: %d\nEstudantes: %d\nNormais: %d\nTotal: R$ %8.2f\n",onibus2.totidosos,onibus2.totestudantes,onibus2.totnormal,totonibus2);
		printf("\n�nibus 3 - 15:00\nIdosos: %d\nEstudantes: %d\nNormais: %d\nTotal: R$ %8.2f\n",onibus3.totidosos,onibus3.totestudantes,onibus3.totnormal,totonibus3);
		printf("\n\nTotal Geral: R$ %8.2f\n\n", totalgeral);
		system("pause");

}

int main(){
	setlocale(LC_ALL, "Portuguese"); // resolvendo o problema da acentua��o

	char opcao1; // op��es do menu principal; char para economizar mem�ria, usa 8 bits enquanto int usa 16
	char tipopassagem; // tipo de passagem selecionado (1=idoso, 2=estudante, 3=normal)
	int quantidade; // quantidade selecionada para compra
	int i; // contador

	//inicializando assentos dispon�veis
	onibus1.totdisponiveis = 36 - onibus1.totidosos - onibus1.totestudantes - onibus1.totnormal;
	onibus2.totdisponiveis = 36 - onibus2.totidosos - onibus2.totestudantes - onibus2.totnormal;
	onibus3.totdisponiveis = 36 - onibus3.totidosos - onibus3.totestudantes - onibus3.totnormal;

	// Criando a enumera��o de tipo booleano
	enum boolean {
    	true = 1, false = 0
	};
	// Permitindo a sua declara��o como um tipo qualquer:
	typedef  enum boolean  bool;
	bool sair=false;

	// Obtendo a data atual
	time_t now = time(NULL);
	struct tm *t = localtime(&now);

	opcao1 = 0;
	
	while(!sair) {
	
		printf( "\nEscolha a op��o:\n\n 1-Venda de passagem SP-RJ para %d/%d/%d\n 2-Fechamento de caixa\n 3-Sair\n\n", t->tm_mday+1,t->tm_mon+1,t->tm_year+1900 );
		opcao1=getche(); //n�o espera enter
	   	   
		switch(opcao1) {
	   		case '1':
	   			onibusescolhido = MenuHorario();
	   			if (onibusescolhido != '0') {
		   			tipopassagem = MenuTipo();
					quantidade = MenuQuantidade(tipopassagem);	   
		   			ImprimeDisponiveis();
		   			MenuAssento(quantidade,tipopassagem);
					ConfirmaCompra(quantidade,tipopassagem,t->tm_mday+1,t->tm_mon+1,t->tm_year+1900);
		   		}
	   			break;
	   		case '2':
				FechaCaixa();
	   			break;
	   		case '3':
	   			sair=true;
	   			break;	   		
	   		default:  
	   			printf("\nOp��o inv�lida. Escolha uma op��o da lista.\n\n");
	   			system("pause");
	   			break;
	   }
		system ( "cls" ); 
	}
	return 0;
}
